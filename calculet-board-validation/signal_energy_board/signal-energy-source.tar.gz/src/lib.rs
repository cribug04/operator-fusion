#![no_std]

#[cfg(all(target_arch = "riscv32", target_os = "none"))]
mod device {
    use npu::prelude::*;

    npu::decls! {
        in_raw: input, bytes = 4096;
        out_raw: output, bytes = 64;
    }

    #[npu::kernel(numerics = "ks1")]
    fn window_energy(input: Ptr<Ddr, f32>, output: Ptr<Ddr, f32>) {
        let samples = vcache::<f32, _>([16, 64]);
        let squared = vcache::<f32, _>([16, 64]);
        let means = vcache::<f32, _>([16, 1]);
        let packed = vcache::<f32, _>([1, 16]);
        samples.load(input.bind::<Read, _>([16, 64]));
        squared.mul(samples, samples);
        means.reduce(Combine::Sum, squared, 1);
        means.mul(means, 0.015625f32);
        packed.reshape(means);
        packed.store(output.bind::<Write, _>([1, 16]));
    }

    #[npu::program(chiplets = 1, cores = 2)]
    pub fn step() {
        if core_rank() == 0 {
            window_energy(in_raw().cast(), out_raw().cast());
        }
        sync_cores();
    }
}
