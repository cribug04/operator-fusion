use npu::prelude::*;

const ROWS: usize = 16;
const COLS: usize = 16;
const N: i32 = (ROWS * COLS) as i32;
const K: usize = 16;
const SCORE_BYTES: u64 = (K * 4) as u64;

npu::decls! {
    in_raw: input, bytes = 1024;
    out_raw: output, bytes = 128;
}

#[npu::kernel(numerics = "ks1")]
fn topk(scores: Ptr<Ddr, f32>, values: Ptr<Ddr, f32>, indices: Ptr<Ddr, i32>) {
    let remaining = vcache::<f32, _>([ROWS, COLS]);
    remaining.load(scores.bind::<Read, _>([ROWS, COLS]));

    let ids = vcache::<i32, _>([ROWS, COLS]);
    let col = vcache::<i32, _>([ROWS, COLS]);
    ids.iota(0);
    col.iota(1);
    ids.mul(ids, COLS as i32);
    ids.add(ids, col);

    let active_ids = vcache::<i32, _>([ROWS, COLS]);
    active_ids.copy(ids);
    let candidates = vcache::<i32, _>([ROWS, COLS]);
    let row_best = vcache::<f32, _>([ROWS, 1]);
    let best = vcache::<f32, _>([1, 1]);
    let row_id = vcache::<i32, _>([ROWS, 1]);
    let best_id = vcache::<i32, _>([1, 1]);
    let hit = vcache::<bool, _>([ROWS, COLS]);

    let lanes = vcache::<i32, _>([1, K]);
    let write_lane = vcache::<bool, _>([1, K]);
    let output_values = vcache::<f32, _>([1, K]);
    let output_ids = vcache::<i32, _>([1, K]);
    lanes.iota(1);
    output_values.fill(0.0f32);
    output_ids.fill(0i32);

    for rank in 0..K {
        row_best.reduce(Combine::Max, remaining, 1);
        best.reduce(Combine::Max, row_best, 0);
        hit.cmp(Pred::Eq, remaining, bcast(best, &[0, 1]));
        candidates.select(hit, active_ids, N);
        row_id.reduce(Combine::Min, candidates, 1);
        best_id.reduce(Combine::Min, row_id, 0);

        write_lane.cmp(Pred::Eq, lanes, rank as i32);
        output_values.select(write_lane, bcast(best, &[0, 1]), output_values);
        output_ids.select(write_lane, bcast(best_id, &[0, 1]), output_ids);

        // Keep an explicit invalid index so f32::MIN itself remains selectable.
        hit.cmp(Pred::Eq, ids, bcast(best_id, &[0, 1]));
        active_ids.select(hit, N, active_ids);
        remaining.select(hit, f32::MIN, remaining);
    }

    output_values.store(values.bind::<Write, _>([1, K]));
    output_ids.store(indices.bind::<Write, _>([1, K]));
}

#[npu::program(chiplets = 1, cores = 2)]
pub fn step() {
    if core_rank() == 0 {
        topk(in_raw().cast(), out_raw().cast(), out_raw().at(SCORE_BYTES).cast());
    }
    sync_cores();
}
