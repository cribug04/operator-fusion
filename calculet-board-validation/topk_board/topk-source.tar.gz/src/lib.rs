#![no_std]

#[cfg(all(target_arch = "riscv32", target_os = "none"))]
mod device;
